<?php

namespace App\Http\Controllers\Admin;

use App\Attendee;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class AttendeesController extends Controller
{
    //
    public function showAttendees($date)
    {
        $data['records'] = Attendee::where("date",$date)->get();
        $data['date'] =$date;

        return view("admin.attendance.attendees",$data);
    }
}
