<footer class="footer">
    © 2018 Christ Embassy Isheri
</footer>